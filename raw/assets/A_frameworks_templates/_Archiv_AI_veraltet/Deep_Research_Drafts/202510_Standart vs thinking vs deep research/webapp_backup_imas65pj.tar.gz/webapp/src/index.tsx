import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Main application route
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AI Prompt Architect - Advanced Framework Builder</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            primary: {
                                50: '#f0f9ff',
                                100: '#e0f2fe',
                                200: '#bae6fd',
                                300: '#7dd3fc',
                                400: '#38bdf8',
                                500: '#0ea5e9',
                                600: '#0284c7',
                                700: '#0369a1',
                                800: '#075985',
                                900: '#0c4a6e',
                            }
                        }
                    }
                }
            }
        </script>
        <style>
            .gradient-bg {
                background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%);
            }
            .glass-effect {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
            .accordion-content {
                display: none;
                overflow: hidden;
            }
            .accordion-content.active {
                display: block;
            }
            .prompt-preview {
                background: #1e293b;
                color: #e2e8f0;
                font-family: 'Fira Code', 'Monaco', monospace;
                font-size: 14px;
                line-height: 1.5;
            }
        </style>
    </head>
    <body class="bg-slate-50 min-h-screen">
        <div class="gradient-bg py-8">
            <div class="container mx-auto px-4">
                <div class="text-center text-white">
                    <h1 class="text-5xl font-bold mb-4">
                        <i class="fas fa-brain mr-3"></i>
                        AI Prompt Architect
                    </h1>
                    <p class="text-xl opacity-90">Advanced Framework Builder for Standard, Thinking & Deep Research Models</p>
                    <p class="text-lg opacity-75 mt-2">Based on the latest research frameworks and best practices</p>
                </div>
            </div>
        </div>

        <div class="container mx-auto px-4 -mt-16 relative z-10">
            <!-- Diagnostic Model Selector -->
            <div class="glass-effect rounded-2xl shadow-2xl p-8 mb-8">
                <h2 class="text-2xl font-bold text-slate-800 mb-6 flex items-center">
                    <i class="fas fa-stethoscope mr-3 text-primary-600"></i>
                    Quick Model Selector - Diagnose Before You Prompt
                </h2>
                <div id="diagnostic-questions" class="space-y-6">
                    <!-- Questions will be loaded here -->
                </div>
                <div id="model-recommendation" class="mt-8 p-6 rounded-xl hidden">
                    <!-- Recommendation will appear here -->
                </div>
            </div>

            <!-- Main Prompt Builder -->
            <div class="glass-effect rounded-2xl shadow-2xl p-8">
                <div class="flex flex-wrap gap-4 mb-8 border-b border-slate-200 pb-6">
                    <button id="tab-standard" class="tab-btn active bg-primary-500 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:bg-primary-600">
                        <i class="fas fa-robot mr-2"></i>Standard Model
                    </button>
                    <button id="tab-thinking" class="tab-btn bg-slate-200 text-slate-700 px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:bg-slate-300">
                        <i class="fas fa-brain mr-2"></i>Thinking Model
                    </button>
                    <button id="tab-deep-research" class="tab-btn bg-slate-200 text-slate-700 px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:bg-slate-300">
                        <i class="fas fa-microscope mr-2"></i>Deep Research
                    </button>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Left Panel: Prompt Builder Layers -->
                    <div>
                        <h3 class="text-xl font-bold text-slate-800 mb-6">Framework Layers</h3>
                        
                        <!-- Standard Model Content -->
                        <div id="content-standard" class="tab-content active">
                            <div class="space-y-4">
                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-bullseye mr-2 text-primary-600"></i>Layer A: Directive</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Role • Goal • Task • Scope • Audience</p>
                                        <div id="directive-standard" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-info-circle mr-2 text-primary-600"></i>Layer B: Context</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Background • Inputs • Few-shot Examples</p>
                                        <div id="context-standard" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-shield-alt mr-2 text-primary-600"></i>Layer C: Constraints</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Limits • Exclusions • Guardrails</p>
                                        <div id="constraints-standard" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-cogs mr-2 text-primary-600"></i>Layer D: Process</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">How to Think • Verification • Heuristics</p>
                                        <div id="process-standard" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-file-export mr-2 text-primary-600"></i>Layer E: Output</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Format • Schema • Style • Evidence</p>
                                        <div id="output-standard" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-check-circle mr-2 text-primary-600"></i>Layer F: Meta-Cognition</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Self-check • Justify • Revise</p>
                                        <div id="metacognition-standard" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Thinking Model Content -->
                        <div id="content-thinking" class="tab-content">
                            <div class="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4">
                                <h4 class="font-bold text-purple-800 mb-2"><i class="fas fa-lightbulb mr-2"></i>Thinking Model Philosophy</h4>
                                <p class="text-purple-700 text-sm">Thinking models have internal reasoning capabilities. Give them high-level goals and trust them to figure out the steps. Prompting them is like briefing a senior expert: define the destination, not the turn-by-turn directions.</p>
                            </div>
                            <div class="space-y-4">
                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-bullseye mr-2 text-primary-600"></i>Layer A: Directive</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">High-level Role • Strategic Goal • Complex Task • Broad Scope • Senior Audience</p>
                                        <div id="directive-thinking" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-info-circle mr-2 text-primary-600"></i>Layer B: Context</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Minimal Essential Context • Core Problem • NO Few-shot (reduces performance)</p>
                                        <div id="context-thinking" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-shield-alt mr-2 text-primary-600"></i>Layer C: Constraints</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Acceptance Tests • High-level Boundaries • Strategic Guardrails</p>
                                        <div id="constraints-thinking" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-cogs mr-2 text-primary-600"></i>Layer D: Process</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Advanced Reasoning • Verification Contracts • NO Explicit Steps</p>
                                        <div id="process-thinking" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-file-export mr-2 text-primary-600"></i>Layer E: Output</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Strategic Format • Reasoning Rationale • No Verbose CoT</p>
                                        <div id="output-thinking" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-check-circle mr-2 text-primary-600"></i>Layer F: Meta-Cognition</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Acceptance Tests • Strategic Validation • Revise-if-Fail</p>
                                        <div id="metacognition-thinking" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Deep Research Model Content -->
                        <div id="content-deep-research" class="tab-content">
                            <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                                <h4 class="font-bold text-green-800 mb-2"><i class="fas fa-search mr-2"></i>Deep Research Philosophy</h4>
                                <p class="text-green-700 text-sm">Deep Research models combine reasoning with live web search and analysis tools. Requires structured, rigorous frameworks to guide the entire research lifecycle from scope definition to evidence synthesis with citations.</p>
                            </div>
                            <div class="space-y-4">
                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-bullseye mr-2 text-primary-600"></i>Layer A: CASINO Framework</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Context • Audience • Scope • Intent • Narrator • Outcome</p>
                                        <div id="directive-deep-research" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-info-circle mr-2 text-primary-600"></i>Layer B: Research Context</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Seed Sources • Evidence Template • Citation Examples</p>
                                        <div id="context-deep-research" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-shield-alt mr-2 text-primary-600"></i>Layer C: Research Standards</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Evidence Requirements • Source Standards • Citation Rules</p>
                                        <div id="constraints-deep-research" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-cogs mr-2 text-primary-600"></i>Layer D: Research Pipeline</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Plan→Search→Triage→Extract→Cross-verify→Synthesize→Cite→Check</p>
                                        <div id="process-deep-research" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-file-export mr-2 text-primary-600"></i>Layer E: Research Output</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Evidence Table • Citations • Confidence • Unknowns</p>
                                        <div id="output-deep-research" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item border border-slate-200 rounded-lg">
                                    <button class="accordion-btn w-full text-left p-4 font-semibold bg-slate-50 hover:bg-slate-100 rounded-t-lg flex justify-between items-center">
                                        <span><i class="fas fa-check-circle mr-2 text-primary-600"></i>Layer F: Research Validation</span>
                                        <i class="fas fa-chevron-down transition-transform duration-300"></i>
                                    </button>
                                    <div class="accordion-content p-4 border-t">
                                        <p class="text-slate-600 mb-4">Source Verification • Evidence Cross-check • Quality Control</p>
                                        <div id="metacognition-deep-research" class="space-y-4">
                                            <!-- Content will be loaded here -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Panel: Live Prompt Preview -->
                    <div>
                        <div class="sticky top-4">
                            <h3 class="text-xl font-bold text-slate-800 mb-4">Live Prompt Preview</h3>
                            <div class="prompt-preview rounded-lg p-6 min-h-96">
                                <div class="text-green-400 mb-2"># Generated Prompt</div>
                                <div id="prompt-output" class="whitespace-pre-wrap">
Select options from the framework layers to generate your optimized prompt...
                                </div>
                            </div>
                            <div class="mt-4 space-x-4">
                                <button id="copy-prompt" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300">
                                    <i class="fas fa-copy mr-2"></i>Copy Prompt
                                </button>
                                <button id="export-json" class="bg-slate-600 hover:bg-slate-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300">
                                    <i class="fas fa-download mr-2"></i>Export JSON
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="mt-16 py-8 bg-slate-800 text-slate-300">
            <div class="container mx-auto px-4 text-center">
                <p class="mb-2">AI Prompt Architect - Advanced Framework Builder</p>
                <p class="text-sm opacity-75">Based on latest research by OpenAI, Trust Insights, and contemporary AI studies</p>
            </div>
        </footer>

        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

// API endpoint for saving prompts
app.post('/api/prompts', async (c) => {
  const promptData = await c.req.json()
  
  // In a real app, you would save to a database
  // For now, just return the data back
  return c.json({
    success: true,
    id: Date.now().toString(),
    data: promptData
  })
})

// API endpoint for getting prompt templates
app.get('/api/templates/:model', (c) => {
  const model = c.req.param('model')
  
  const templates = {
    standard: {
      shell: `<role>You are a {role} for {audience}.</role>
<task>Goal: {goal}. Task: {task}. Scope: {scope}.</task>
<context>{context}</context>
<constraints>Length={length}; Exclude={exclusions}; Style={style}.</constraints>
<output>Return ONLY {format}. If JSON, schema={schema}.</output>
<self_check>Confirm accuracy, coverage, format. If any fail, fix then answer.</self_check>`,
      description: "Minimal, fast prompts for standard models"
    },
    thinking: {
      shell: `<role>Senior {role} for {audience}.</role>
<task>Ultimate objective: {objective}. Specific task: {task}. Scope: {scope}.</task>
<context>{context}</context>
<constraints>Acceptance tests: {tests}. Guardrails: {guardrails}.</constraints>
<process>Reasoning={reasoning}. Verification={verification}; state assumptions; prefer primary sources.</process>
<output>Format={format}. Include {sections}.</output>
<self_check>Test {tests}; if any fail, revise; provide brief rationale (no chain-of-thought).</self_check>`,
      description: "Reasoned, strict prompts for thinking models"
    },
    'deep-research': {
      shell: `<CASINO>
Context={context}; Audience={audience}; Scope={scope};
Intent={intent}; Narrator={narrator}; Outcome={outcome}.
</CASINO>

<role>Research lead for {audience}.</role>
<task>Operate within {scope}; produce {deliverables}. Use provided inputs.</task>
<context>{context}</context>
<constraints>Recency={window}; Min_sources={min_sources}; Citation={citation_style}; Exclusions={exclusions}; Guardrails={guardrails}.</constraints>
<process>
DeepResearch=true. Run: Plan→Search→Triage→Extract→Cross-verify→Synthesize→Cite→Self-check.
Use: [web], [calculator], [code], as needed. Prefer primary sources; log publisher/author/date.
</process>
<output>
Return ONLY {format}.
Must include: Executive summary; Evidence table (source,publisher,author,date,URL); Inline citations; Residual unknowns; Confidence (0–100%).
</output>
<self_check>
Re-verify dates & links; confirm ≥2 independent confirmations for key claims; pass acceptance tests; if any fail, revise then present final.
</self_check>`,
      description: "Agentic, citational prompts for deep research models"
    }
  }
  
  return c.json(templates[model] || { error: 'Template not found' })
})

export default app