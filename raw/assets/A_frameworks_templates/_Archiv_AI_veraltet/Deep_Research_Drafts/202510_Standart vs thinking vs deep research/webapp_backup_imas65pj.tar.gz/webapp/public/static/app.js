// AI Prompt Architect - Advanced Framework Builder
class PromptArchitect {
    constructor() {
        this.currentModel = 'standard';
        this.promptData = {
            standard: {},
            thinking: {},
            'deep-research': {}
        };
        this.diagnosticAnswers = {};
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadDiagnosticQuestions();
        this.loadFrameworkLayers();
        this.updatePromptPreview();
    }

    setupEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabId = e.target.id.replace('tab-', '');
                this.switchTab(tabId);
            });
        });

        // Accordion functionality
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('accordion-btn') || e.target.closest('.accordion-btn')) {
                const btn = e.target.classList.contains('accordion-btn') ? e.target : e.target.closest('.accordion-btn');
                const content = btn.nextElementSibling;
                const icon = btn.querySelector('.fa-chevron-down, .fa-chevron-up');
                
                if (content.classList.contains('active')) {
                    content.classList.remove('active');
                    icon.classList.remove('fa-chevron-up');
                    icon.classList.add('fa-chevron-down');
                } else {
                    content.classList.add('active');
                    icon.classList.remove('fa-chevron-down');
                    icon.classList.add('fa-chevron-up');
                }
            }
        });

        // Copy prompt functionality
        document.getElementById('copy-prompt').addEventListener('click', () => {
            const promptText = document.getElementById('prompt-output').textContent;
            navigator.clipboard.writeText(promptText).then(() => {
                this.showNotification('Prompt copied to clipboard!');
            });
        });

        // Export JSON functionality
        document.getElementById('export-json').addEventListener('click', () => {
            this.exportJSON();
        });
    }

    loadDiagnosticQuestions() {
        const questions = [
            {
                id: 'fresh_facts',
                question: '1. Fresh facts needed (dated/citable)?',
                options: [
                    { value: 'yes', label: 'Yes → Deep-Research (agentic tool-use + citations)', model: 'deep-research' },
                    { value: 'no', label: 'No → Continue to next question', model: null }
                ]
            },
            {
                id: 'multi_step_reasoning',
                question: '2. Multi-step reasoning required (math/logic/derivations)?',
                options: [
                    { value: 'yes', label: 'Yes → Thinking (reasoning model)', model: 'thinking' },
                    { value: 'no', label: 'No → Standard is usually enough', model: 'standard' }
                ]
            },
            {
                id: 'latency_tolerance',
                question: '3. Tolerance for latency/cost?',
                options: [
                    { value: 'low', label: 'Low → Standard (or Thinking with minimal scaffolding)', model: 'standard' },
                    { value: 'medium', label: 'Medium → Thinking', model: 'thinking' },
                    { value: 'high', label: 'High → Deep-Research', model: 'deep-research' }
                ]
            },
            {
                id: 'governance_critical',
                question: '4. Output governance critical (evidence tables, audits)?',
                options: [
                    { value: 'yes', label: 'Yes → Thinking (Strict) or Deep-Research with verification pipeline', model: 'thinking' },
                    { value: 'no', label: 'No → Continue', model: null }
                ]
            },
            {
                id: 'high_ambiguity',
                question: '5. Ambiguity is high and stakes high?',
                options: [
                    { value: 'yes', label: 'Yes → Use Thinking/Deep-Research + Step-Back and acceptance tests', model: 'thinking' },
                    { value: 'no', label: 'No → Continue', model: null }
                ]
            },
            {
                id: 'automation_output',
                question: '6. Will output feed automation?',
                options: [
                    { value: 'yes', label: 'Yes → Require schema\'d JSON + validation step (any model)', model: null },
                    { value: 'no', label: 'No → Continue', model: null }
                ]
            }
        ];

        const container = document.getElementById('diagnostic-questions');
        questions.forEach(q => {
            const questionDiv = document.createElement('div');
            questionDiv.className = 'bg-white border border-slate-200 rounded-lg p-6';
            questionDiv.innerHTML = `
                <h4 class="font-semibold text-slate-800 mb-4">${q.question}</h4>
                <div class="space-y-2">
                    ${q.options.map(opt => `
                        <label class="flex items-start space-x-3 p-3 hover:bg-slate-50 rounded-md cursor-pointer">
                            <input type="radio" name="${q.id}" value="${opt.value}" class="mt-1 form-radio text-primary-600">
                            <span class="text-slate-700">${opt.label}</span>
                        </label>
                    `).join('')}
                </div>
            `;
            container.appendChild(questionDiv);
        });

        // Add event listeners for diagnostic questions
        container.addEventListener('change', (e) => {
            if (e.target.type === 'radio') {
                this.diagnosticAnswers[e.target.name] = e.target.value;
                this.updateModelRecommendation();
            }
        });
    }

    updateModelRecommendation() {
        const answers = this.diagnosticAnswers;
        let recommendedModel = 'standard';
        let reasoning = [];

        // Analyze answers to determine best model
        if (answers.fresh_facts === 'yes') {
            recommendedModel = 'deep-research';
            reasoning.push('Fresh facts and citations required');
        } else if (answers.multi_step_reasoning === 'yes') {
            recommendedModel = 'thinking';
            reasoning.push('Multi-step reasoning needed');
        } else if (answers.latency_tolerance === 'high') {
            recommendedModel = 'deep-research';
            reasoning.push('High tolerance for latency allows for comprehensive research');
        } else if (answers.latency_tolerance === 'medium') {
            recommendedModel = 'thinking';
            reasoning.push('Medium latency tolerance suits reasoning models');
        }

        if (answers.governance_critical === 'yes' || answers.high_ambiguity === 'yes') {
            if (recommendedModel === 'standard') {
                recommendedModel = 'thinking';
                reasoning.push('Governance/ambiguity concerns require enhanced reasoning');
            }
        }

        this.showModelRecommendation(recommendedModel, reasoning);
    }

    showModelRecommendation(model, reasoning) {
        const container = document.getElementById('model-recommendation');
        const modelNames = {
            'standard': 'Standard Model',
            'thinking': 'Thinking Model', 
            'deep-research': 'Deep Research Model'
        };

        const modelColors = {
            'standard': 'bg-blue-50 border-blue-200 text-blue-800',
            'thinking': 'bg-purple-50 border-purple-200 text-purple-800',
            'deep-research': 'bg-green-50 border-green-200 text-green-800'
        };

        container.innerHTML = `
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-xl font-bold text-slate-800">Recommended Model</h3>
                <button class="text-primary-600 hover:text-primary-700" onclick="promptArchitect.switchTab('${model}')">
                    Switch to ${modelNames[model]} →
                </button>
            </div>
            <div class="${modelColors[model]} border-2 rounded-lg p-6">
                <h4 class="font-bold text-lg mb-2">${modelNames[model]}</h4>
                <ul class="space-y-1">
                    ${reasoning.map(r => `<li>• ${r}</li>`).join('')}
                </ul>
            </div>
        `;
        container.classList.remove('hidden');
    }

    switchTab(modelType) {
        this.currentModel = modelType;

        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active', 'bg-primary-500', 'text-white');
            btn.classList.add('bg-slate-200', 'text-slate-700');
        });
        
        document.getElementById(`tab-${modelType}`).classList.remove('bg-slate-200', 'text-slate-700');
        document.getElementById(`tab-${modelType}`).classList.add('active', 'bg-primary-500', 'text-white');

        // Update content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`content-${modelType}`).classList.add('active');

        this.updatePromptPreview();
    }

    loadFrameworkLayers() {
        // Framework data based on the PDF
        const frameworkData = {
            standard: {
                directive: {
                    role: ['auditor', 'strategy consultant', 'senior market researcher', 'data analyst', 'PM', 'policy analyst', 'technical writer', 'copy chief', 'teacher', 'explainer for non-experts'],
                    goal: ['analyze', 'compare', 'explain', 'classify', 'extract', 'summarize', 'evaluate', 'plan/strategy', 'draft', 'outline', 'design framework', 'simulate'],
                    task: ['1-pager brief', '500-word summary', '10 bullets', '2×2', 'table', 'JSON schema', 'slide outline', 'email'],
                    scope: ['provided sources only', 'provided + web sources', 'specific domains', 'time window constraints', 'geo/industry constraints'],
                    audience: ['C-suite', 'board', 'investors', 'sales leaders', 'supply chain', 'product/eng', 'general public', 'grade level specific']
                },
                context: {
                    background: 'Domain notes, definitions, project brief, glossary',
                    inputs: 'Pasted text, file references, structured fields, URLs',
                    fewshot: '1–3 positive examples, optionally 1 counter-example'
                },
                constraints: {
                    length: ['≤150 words', '≤300 words', '≤500 words', '≤10 bullets', 'exact 5 items'],
                    style: ['active voice', 'concise', 'executive brief', 'reading level 8', 'reading level 12'],
                    exclusions: ['speculation', 'vendor pitches', 'personal data', 'pricing', 'legal advice'],
                    guardrails: ['no legal/medical/financial advice', 'anonymize PII', 'brand style rules', 'prompt-injection policy']
                },
                process: {
                    reasoning: ['Direct (no explicit reasoning)', 'Step-Back (abstract principles → apply)', 'Least-to-Most (decompose sub-problems)'],
                    verification: ['None (draft only)', 'Light (sanity-check numbers)', 'Strict (facts must be verifiable)']
                },
                output: {
                    format: ['Markdown sections', 'table', 'JSON', 'YAML', 'CSV', 'slide outline', 'email'],
                    schema: 'Keys/types/arrays/ranges (e.g., confidence: 0–1)',
                    style: ['active', 'analytical', 'exec-brief', 'conversational-professional'],
                    evidence: 'Optional inline citations'
                },
                metacognition: {
                    selfcheck: ['1-line accuracy check', 'format validation', 'coverage check'],
                    justify: 'Brief key choices/assumptions',
                    revise: 'Fix if failed, then output final'
                }
            },
            thinking: {
                directive: {
                    role: ['Senior strategist', 'Principal engineer', 'Senior analyst', 'Research director', 'Chief advisor', 'Expert consultant'],
                    goal: ['Analyze impact of X on Y', 'Develop strategy for scenario', 'Evaluate trade-offs between A and B', 'Assess risks and opportunities', 'Design optimal solution', 'Create comprehensive framework'],
                    task: ['Strategic analysis', 'Decision framework', 'Risk assessment', 'Optimization plan', 'System design', 'Policy recommendation'],
                    scope: ['High-level strategic view', 'Cross-functional analysis', 'Long-term implications', 'System-wide impact', 'Multi-stakeholder perspective'],
                    audience: ['C-suite executives', 'Board of directors', 'Senior leadership', 'Strategic committee', 'Investment team', 'Policy makers']
                },
                context: {
                    background: 'Minimal essential context - avoid over-constraining the reasoning process',
                    inputs: 'Core problem statement and key parameters only',
                    fewshot: 'AVOID - Few-shot learning often confuses thinking models and reduces performance'
                },
                constraints: {
                    length: ['No specific limit - focus on thoroughness', 'Executive summary format', 'Key insights only'],
                    style: ['Strategic', 'Analytical', 'Evidence-based', 'Systematic reasoning'],
                    exclusions: ['Speculation without evidence', 'Premature conclusions', 'Surface-level analysis'],
                    guardrails: ['Focus on long-term implications', 'Prioritize user safety', 'Solution must be scalable', 'Consider ethical implications', 'Validate key assumptions']
                },
                process: {
                    reasoning: ['Step-Back (abstract principles → apply)', 'Least-to-Most (decompose sub-problems)', 'Self-Consistency (k=3-5 samples)', 'Skeleton-of-Thought (outline then expand)'],
                    verification: ['Light (sanity-check key points)', 'Strict (facts must be verifiable with sources)', 'Acceptance tests (numbered criteria)']
                },
                output: {
                    format: ['Structured analysis', 'Decision framework', 'Executive briefing', 'Strategic roadmap', 'Risk matrix', 'Recommendation report'],
                    schema: 'Include reasoning rationale, key assumptions, confidence levels',
                    style: ['Executive-level', 'Strategic', 'Evidence-driven', 'Action-oriented'],
                    evidence: 'Brief rationale + key assumptions (no verbose chain-of-thought)'
                },
                metacognition: {
                    selfcheck: ['Test acceptance criteria', 'Verify logic consistency', 'Check assumption validity', 'Validate evidence quality'],
                    justify: 'Brief rationale for key strategic choices and assumptions',
                    revise: 'If acceptance tests fail, revise approach and re-analyze'
                }
            },
            'deep-research': {
                directive: {
                    role: ['Research lead', 'Principal investigator', 'Senior researcher', 'Intelligence analyst', 'Evidence specialist', 'Data scientist'],
                    goal: ['Comprehensive evidence-based analysis', 'Multi-source research synthesis', 'Fact-checked investigation', 'Systematic literature review', 'Market intelligence report'],
                    task: ['Research report with citations', 'Evidence synthesis', 'Comparative analysis', 'Trend analysis', 'Due diligence report', 'Policy brief'],
                    scope: ['Specific timeframe and geography', 'Defined source domains', 'Minimum evidence threshold', 'Citation requirements'],
                    audience: ['Decision makers', 'Investment committee', 'Research community', 'Policy makers', 'Academic reviewers', 'Due diligence team']
                },
                context: {
                    background: 'Research scope definition, must-use sources, evidence table template',
                    inputs: 'Seed documents, key search terms, trusted source lists, untrusted content (marked)',
                    fewshot: 'Citation format examples, evidence table samples'
                },
                constraints: {
                    length: ['Comprehensive report', 'Executive summary + full analysis', 'Evidence-based conclusions only'],
                    style: ['Academic rigor', 'Journalistic neutrality', 'Analytical precision', 'Fact-based reporting'],
                    exclusions: ['Speculation', 'Unverified claims', 'Biased sources', 'Outdated information', 'Paywalled content'],
                    guardrails: ['≥2 independent sources per key claim', 'Verify publication dates', 'Label speculative statements', 'Anonymize PII', 'Cross-verify contradictory evidence']
                },
                process: {
                    reasoning: ['Deep-Research pipeline: Plan→Search→Triage→Extract→Cross-verify→Synthesize→Cite→Self-check', 'Skeleton-of-Thought for structure', 'CRITIC (tool-augmented critique)', 'Chain-of-Verification (CoVe)'],
                    verification: ['Strict (≥2 independent confirmations)', 'Source validation (publisher/author/date)', 'Cross-verification of claims', 'Citation accuracy check']
                },
                output: {
                    format: ['Research report + Evidence table', 'Executive summary + Full findings', 'Structured analysis with citations', 'Evidence matrix format'],
                    schema: 'Executive summary, Evidence table (source|publisher|author|date|URL), Inline citations, Residual unknowns, Confidence (0-100%)',
                    style: ['Formal research', 'Objective analysis', 'Citation-heavy', 'Evidence-driven'],
                    evidence: 'Full evidence table + inline citations + confidence ratings + residual unknowns list'
                },
                metacognition: {
                    selfcheck: ['Re-verify dates & links', '≥2 independent confirmations for key claims', 'Citation format consistency', 'Evidence quality assessment'],
                    justify: 'Methodology explanation, source selection rationale, confidence calibration',
                    revise: 'Fix failed verification checks, update evidence table, adjust confidence ratings'
                }
            }
        };

        // Load all models
        this.loadLayerContent('standard', frameworkData.standard);
        this.loadLayerContent('thinking', frameworkData.thinking);
        this.loadLayerContent('deep-research', frameworkData['deep-research']);
    }

    loadLayerContent(model, data) {
        // Load Directive layer
        const directiveContainer = document.getElementById(`directive-${model}`);
        if (directiveContainer) {
            directiveContainer.innerHTML = `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Role</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'directive', 'role', this.value)">
                            <option value="">Select a role...</option>
                            ${data.directive.role.map(r => `<option value="${r}">${r}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Goal</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'directive', 'goal', this.value)">
                            <option value="">Select a goal...</option>
                            ${data.directive.goal.map(g => `<option value="${g}">${g}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Task</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'directive', 'task', this.value)">
                            <option value="">Select a task...</option>
                            ${data.directive.task.map(t => `<option value="${t}">${t}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Audience</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'directive', 'audience', this.value)">
                            <option value="">Select audience...</option>
                            ${data.directive.audience.map(a => `<option value="${a}">${a}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Scope</label>
                        <textarea class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" rows="3" placeholder="Define the scope and boundaries..." onchange="promptArchitect.updatePromptData('${model}', 'directive', 'scope', this.value)"></textarea>
                    </div>
                </div>
            `;
        }

        // Load Context layer
        const contextContainer = document.getElementById(`context-${model}`);
        if (contextContainer) {
            contextContainer.innerHTML = `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Background & Context</label>
                        <textarea class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" rows="4" placeholder="Provide background information, domain notes, definitions..." onchange="promptArchitect.updatePromptData('${model}', 'context', 'background', this.value)"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Input Data</label>
                        <textarea class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" rows="4" placeholder="Paste text, file references, structured data..." onchange="promptArchitect.updatePromptData('${model}', 'context', 'inputs', this.value)"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Few-shot Examples</label>
                        <textarea class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" rows="4" placeholder="Provide 1-3 positive examples of input/output format..." onchange="promptArchitect.updatePromptData('${model}', 'context', 'fewshot', this.value)"></textarea>
                        <p class="text-sm text-slate-500 mt-1">Standard: 3–5 bullets + 1 example</p>
                    </div>
                </div>
            `;
        }

        // Load Constraints layer
        const constraintsContainer = document.getElementById(`constraints-${model}`);
        if (constraintsContainer) {
            constraintsContainer.innerHTML = `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Length Constraints</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'constraints', 'length', this.value)">
                            <option value="">Select length limit...</option>
                            ${data.constraints.length.map(l => `<option value="${l}">${l}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Style Requirements</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'constraints', 'style', this.value)">
                            <option value="">Select style...</option>
                            ${data.constraints.style.map(s => `<option value="${s}">${s}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Exclusions</label>
                        <div class="space-y-2">
                            ${data.constraints.exclusions.map(e => `
                                <label class="flex items-center space-x-2">
                                    <input type="checkbox" class="form-checkbox text-primary-600" value="${e}" onchange="promptArchitect.updateConstraintsList('${model}', 'exclusions', this)">
                                    <span class="text-sm">${e}</span>
                                </label>
                            `).join('')}
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Guardrails</label>
                        <div class="space-y-2">
                            ${data.constraints.guardrails.map(g => `
                                <label class="flex items-center space-x-2">
                                    <input type="checkbox" class="form-checkbox text-primary-600" value="${g}" onchange="promptArchitect.updateConstraintsList('${model}', 'guardrails', this)">
                                    <span class="text-sm">${g}</span>
                                </label>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        }

        // Load Process layer
        const processContainer = document.getElementById(`process-${model}`);
        if (processContainer) {
            processContainer.innerHTML = `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Reasoning Mode</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'process', 'reasoning', this.value)">
                            <option value="">Select reasoning approach...</option>
                            ${data.process.reasoning.map(r => `<option value="${r}">${r}</option>`).join('')}
                        </select>
                        <p class="text-sm text-slate-500 mt-1">Standard default: Direct or brief Step-Back</p>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Verification Level</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'process', 'verification', this.value)">
                            <option value="">Select verification level...</option>
                            ${data.process.verification.map(v => `<option value="${v}">${v}</option>`).join('')}
                        </select>
                        <p class="text-sm text-slate-500 mt-1">Standard default: None/Light</p>
                    </div>
                </div>
            `;
        }

        // Load Output layer
        const outputContainer = document.getElementById(`output-${model}`);
        if (outputContainer) {
            outputContainer.innerHTML = `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Output Format</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'output', 'format', this.value)">
                            <option value="">Select format...</option>
                            ${data.output.format.map(f => `<option value="${f}">${f}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Schema (for JSON/structured output)</label>
                        <textarea class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" rows="3" placeholder="Define keys, types, ranges..." onchange="promptArchitect.updatePromptData('${model}', 'output', 'schema', this.value)"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Style & Tone</label>
                        <select class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" onchange="promptArchitect.updatePromptData('${model}', 'output', 'style', this.value)">
                            <option value="">Select style...</option>
                            ${data.output.style.map(s => `<option value="${s}">${s}</option>`).join('')}
                        </select>
                    </div>
                </div>
            `;
        }

        // Load Meta-Cognition layer
        const metacognitionContainer = document.getElementById(`metacognition-${model}`);
        if (metacognitionContainer) {
            metacognitionContainer.innerHTML = `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Self-Check Requirements</label>
                        <div class="space-y-2">
                            ${data.metacognition.selfcheck.map(s => `
                                <label class="flex items-center space-x-2">
                                    <input type="checkbox" class="form-checkbox text-primary-600" value="${s}" onchange="promptArchitect.updateConstraintsList('${model}', 'selfcheck', this)">
                                    <span class="text-sm">${s}</span>
                                </label>
                            `).join('')}
                        </div>
                        <p class="text-sm text-slate-500 mt-1">Standard default: 1-line self-check</p>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-slate-700 mb-2">Justification Level</label>
                        <textarea class="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-primary-500" rows="2" placeholder="Brief key choices/assumptions" onchange="promptArchitect.updatePromptData('${model}', 'metacognition', 'justify', this.value)"></textarea>
                    </div>
                </div>
            `;
        }
    }

    updatePromptData(model, layer, field, value) {
        if (!this.promptData[model]) this.promptData[model] = {};
        if (!this.promptData[model][layer]) this.promptData[model][layer] = {};
        this.promptData[model][layer][field] = value;
        this.updatePromptPreview();
    }

    updateConstraintsList(model, field, checkbox) {
        if (!this.promptData[model]) this.promptData[model] = {};
        if (!this.promptData[model].constraints) this.promptData[model].constraints = {};
        if (!this.promptData[model].metacognition) this.promptData[model].metacognition = {};
        
        const container = field === 'selfcheck' ? this.promptData[model].metacognition : this.promptData[model].constraints;
        
        if (!container[field]) container[field] = [];
        
        if (checkbox.checked) {
            if (!container[field].includes(checkbox.value)) {
                container[field].push(checkbox.value);
            }
        } else {
            container[field] = container[field].filter(item => item !== checkbox.value);
        }
        
        this.updatePromptPreview();
    }

    updatePromptPreview() {
        const data = this.promptData[this.currentModel] || {};
        let prompt = '';

        if (this.currentModel === 'standard') {
            prompt = this.generateStandardPrompt(data);
        } else if (this.currentModel === 'thinking') {
            prompt = this.generateThinkingPrompt(data);
        } else if (this.currentModel === 'deep-research') {
            prompt = this.generateDeepResearchPrompt(data);
        }

        document.getElementById('prompt-output').textContent = prompt;
    }

    generateStandardPrompt(data) {
        let prompt = '# Generated Standard Model Prompt\n\n';

        // Directive layer
        if (data.directive) {
            const d = data.directive;
            if (d.role || d.audience) {
                prompt += `<role>You are a ${d.role || '[ROLE]'} for ${d.audience || '[AUDIENCE]'}.</role>\n\n`;
            }
            
            if (d.goal || d.task || d.scope) {
                prompt += `<task>Goal: ${d.goal || '[GOAL]'}. Task: ${d.task || '[TASK]'}. Scope: ${d.scope || '[SCOPE]'}.</task>\n\n`;
            }
        }

        // Context layer
        if (data.context) {
            let contextContent = '';
            if (data.context.background) contextContent += data.context.background + '\n\n';
            if (data.context.inputs) contextContent += data.context.inputs + '\n\n';
            if (data.context.fewshot) contextContent += 'Examples:\n' + data.context.fewshot + '\n\n';
            
            if (contextContent.trim()) {
                prompt += `<context>\n${contextContent.trim()}\n</context>\n\n`;
            }
        }

        // Constraints layer
        if (data.constraints) {
            let constraintsParts = [];
            if (data.constraints.length) constraintsParts.push(`Length=${data.constraints.length}`);
            if (data.constraints.style) constraintsParts.push(`Style=${data.constraints.style}`);
            if (data.constraints.exclusions && data.constraints.exclusions.length > 0) {
                constraintsParts.push(`Exclude=[${data.constraints.exclusions.join(', ')}]`);
            }
            if (data.constraints.guardrails && data.constraints.guardrails.length > 0) {
                constraintsParts.push(`Guardrails=[${data.constraints.guardrails.join(', ')}]`);
            }

            if (constraintsParts.length > 0) {
                prompt += `<constraints>${constraintsParts.join('; ')}.</constraints>\n\n`;
            }
        }

        // Process layer (for standard model, usually minimal)
        if (data.process && (data.process.reasoning || data.process.verification)) {
            let processParts = [];
            if (data.process.reasoning) processParts.push(`Reasoning=${data.process.reasoning}`);
            if (data.process.verification) processParts.push(`Verification=${data.process.verification}`);
            
            if (processParts.length > 0) {
                prompt += `<process>${processParts.join('; ')}.</process>\n\n`;
            }
        }

        // Output layer
        if (data.output) {
            let outputParts = [];
            if (data.output.format) outputParts.push(`Return ONLY ${data.output.format}`);
            if (data.output.schema && data.output.format && data.output.format.toLowerCase().includes('json')) {
                outputParts.push(`Schema: ${data.output.schema}`);
            }
            if (data.output.style) outputParts.push(`Style: ${data.output.style}`);

            if (outputParts.length > 0) {
                prompt += `<output>${outputParts.join('. ')}.</output>\n\n`;
            }
        }

        // Meta-cognition layer
        let selfCheckParts = ['Confirm accuracy, coverage, format'];
        if (data.metacognition && data.metacognition.selfcheck && data.metacognition.selfcheck.length > 0) {
            selfCheckParts = data.metacognition.selfcheck;
        }
        prompt += `<self_check>${selfCheckParts.join(', ')}. If any fail, fix then answer.</self_check>`;

        return prompt;
    }

    generateThinkingPrompt(data) {
        let prompt = '# Generated Thinking Model Prompt\n\n';

        // Directive layer - Senior level
        if (data.directive) {
            const d = data.directive;
            if (d.role || d.audience) {
                prompt += `<role>Senior ${d.role || '[ROLE]'} for ${d.audience || '[AUDIENCE]'}.</role>\n\n`;
            }
            
            if (d.goal || d.task || d.scope) {
                prompt += `<task>Ultimate objective: ${d.goal || '[SUCCESS_METRIC]'}. Specific task: ${d.task || '[TASK]'}. Scope: ${d.scope || '[SCOPE]'}.</task>\n\n`;
            }
        }

        // Context layer - Minimal and essential
        if (data.context && data.context.background) {
            prompt += `<context>\n${data.context.background}\n</context>\n\n`;
        }

        // Constraints layer - Acceptance tests and guardrails
        if (data.constraints) {
            let constraintsParts = [];
            if (data.constraints.guardrails && data.constraints.guardrails.length > 0) {
                constraintsParts.push(`Acceptance tests: [${data.constraints.guardrails.join(', ')}]`);
            }
            if (data.constraints.exclusions && data.constraints.exclusions.length > 0) {
                constraintsParts.push(`Guardrails: [${data.constraints.exclusions.join(', ')}]`);
            }

            if (constraintsParts.length > 0) {
                prompt += `<constraints>${constraintsParts.join('. ')}.</constraints>\n\n`;
            }
        }

        // Process layer - Advanced reasoning
        if (data.process) {
            let processParts = [];
            if (data.process.reasoning) processParts.push(`Reasoning=${data.process.reasoning}`);
            if (data.process.verification) processParts.push(`Verification=${data.process.verification}; state assumptions; prefer primary sources`);
            
            if (processParts.length > 0) {
                prompt += `<process>${processParts.join('. ')}.</process>\n\n`;
            }
        }

        // Output layer - Include sections and rationale
        if (data.output) {
            let outputParts = [];
            if (data.output.format) outputParts.push(`Format=${data.output.format}`);
            if (data.output.style) outputParts.push(`Include ${data.output.style} sections`);

            if (outputParts.length > 0) {
                prompt += `<output>${outputParts.join('. ')}.</output>\n\n`;
            }
        }

        // Meta-cognition layer - Test acceptance criteria
        let selfCheckParts = [];
        if (data.metacognition && data.metacognition.selfcheck && data.metacognition.selfcheck.length > 0) {
            selfCheckParts = data.metacognition.selfcheck;
        } else {
            selfCheckParts = ['Test acceptance criteria', 'Verify logic consistency'];
        }
        prompt += `<self_check>${selfCheckParts.join('; ')}; if any fail, revise; provide brief rationale (no chain-of-thought).</self_check>`;

        return prompt;
    }

    generateDeepResearchPrompt(data) {
        let prompt = '# Generated Deep Research Model Prompt\n\n';

        // CASINO Framework
        if (data.directive) {
            const d = data.directive;
            let casinoParts = [];
            if (d.scope) casinoParts.push(`Context=${d.scope}`);
            if (d.audience) casinoParts.push(`Audience=${d.audience}`);
            if (d.scope) casinoParts.push(`Scope=${d.scope}`);
            if (d.goal) casinoParts.push(`Intent=${d.goal}`);
            if (d.role) casinoParts.push(`Narrator=${d.role}`);
            if (d.task) casinoParts.push(`Outcome=${d.task}`);

            if (casinoParts.length > 0) {
                prompt += `<CASINO>\n${casinoParts.join('; ')}.\n</CASINO>\n\n`;
            }

            if (d.role || d.audience) {
                prompt += `<role>Research lead for ${d.audience || '[AUDIENCE]'}.</role>\n\n`;
            }
            
            if (d.scope || d.task) {
                prompt += `<task>Operate within ${d.scope || '[SCOPE]'}; produce ${d.task || '[DELIVERABLES]'}. Use provided inputs.</task>\n\n`;
            }
        }

        // Context layer - Seed docs and definitions
        if (data.context) {
            let contextContent = '';
            if (data.context.background) contextContent += data.context.background + '\n\n';
            if (data.context.inputs) contextContent += 'Input sources (mark untrusted):\n' + data.context.inputs + '\n\n';
            
            if (contextContent.trim()) {
                prompt += `<context>\n${contextContent.trim()}\n</context>\n\n`;
            }
        }

        // Constraints layer - Research standards
        if (data.constraints) {
            let constraintsParts = [];
            if (data.constraints.length) constraintsParts.push(`Recency=${data.constraints.length}`);
            constraintsParts.push('Min_sources=[2 independent per key claim]');
            if (data.constraints.style) constraintsParts.push(`Citation=${data.constraints.style}`);
            if (data.constraints.exclusions && data.constraints.exclusions.length > 0) {
                constraintsParts.push(`Exclusions=[${data.constraints.exclusions.join(', ')}]`);
            }
            if (data.constraints.guardrails && data.constraints.guardrails.length > 0) {
                constraintsParts.push(`Guardrails=[${data.constraints.guardrails.join(', ')}]`);
            }

            if (constraintsParts.length > 0) {
                prompt += `<constraints>${constraintsParts.join('; ')}.</constraints>\n\n`;
            }
        }

        // Process layer - Deep Research pipeline
        prompt += `<process>\nDeepResearch=true. Run: Plan→Search→Triage→Extract→Cross-verify→Synthesize→Cite→Self-check.\n`;
        if (data.process && data.process.reasoning) {
            prompt += `Use: ${data.process.reasoning}.\n`;
        }
        prompt += `Use: [web], [calculator], [code], as needed. Prefer primary sources; log publisher/author/date.\n</process>\n\n`;

        // Output layer - Research deliverables
        prompt += `<output>\n`;
        if (data.output && data.output.format) {
            prompt += `Return ONLY ${data.output.format}.\n`;
        } else {
            prompt += `Return ONLY Markdown.\n`;
        }
        prompt += `Must include: Executive summary; Evidence table (source,publisher,author,date,URL); Inline citations; Residual unknowns; Confidence (0–100%).\n</output>\n\n`;

        // Meta-cognition layer - Research validation
        let selfCheckParts = [
            'Re-verify dates & links',
            'confirm ≥2 independent confirmations for key claims',
            'pass acceptance tests'
        ];
        if (data.metacognition && data.metacognition.selfcheck && data.metacognition.selfcheck.length > 0) {
            selfCheckParts = [...selfCheckParts, ...data.metacognition.selfcheck];
        }
        prompt += `<self_check>\n${selfCheckParts.join('; ')}; if any fail, revise then present final.\n</self_check>`;

        return prompt;
    }

    showNotification(message) {
        // Create and show a notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    exportJSON() {
        const exportData = {
            model: this.currentModel,
            diagnosticAnswers: this.diagnosticAnswers,
            promptData: this.promptData[this.currentModel],
            generatedPrompt: document.getElementById('prompt-output').textContent,
            timestamp: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `prompt-architect-${this.currentModel}-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showNotification('Prompt configuration exported as JSON!');
    }
}

// Initialize the application when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.promptArchitect = new PromptArchitect();
});