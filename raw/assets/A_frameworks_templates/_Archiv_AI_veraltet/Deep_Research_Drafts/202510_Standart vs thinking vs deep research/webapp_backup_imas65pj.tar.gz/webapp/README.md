# AI Prompt Architect

## Project Overview
- **Name**: AI Prompt Architect - Advanced Framework Builder
- **Goal**: Interactive web application for building optimized AI prompts using research-based frameworks for Standard, Thinking, and Deep Research models
- **Features**: Diagnostic model selector, 6-layer framework builder, live prompt preview, export functionality

## URLs
- **Development**: https://3000-imas65pj5k3dk07zp9jas-6532622b.e2b.dev
- **API Endpoints**: 
  - `POST /api/prompts` - Save prompt configurations
  - `GET /api/templates/:model` - Get prompt templates for specific models
- **GitHub**: *To be configured*

## Current Features ✅

### 1. Diagnostic Model Selector
- **Quick Model Selector**: Interactive questionnaire to diagnose optimal AI model
- **7 Decision Questions**: Fresh facts, reasoning requirements, latency tolerance, governance, ambiguity, automation, security
- **Smart Recommendations**: Automatically suggests Standard, Thinking, or Deep Research model based on answers
- **Visual Guidance**: Color-coded recommendations with reasoning explanations

### 2. Framework Layers (All Models - Complete)

**Standard Model:**
- **Layer A - Directive**: Role, Goal, Task, Scope, Audience selection
- **Layer B - Context**: Background info, input data, few-shot examples  
- **Layer C - Constraints**: Length limits, style requirements, exclusions, guardrails
- **Layer D - Process**: Reasoning modes, verification levels
- **Layer E - Output**: Format specification, schema definition, style settings
- **Layer F - Meta-Cognition**: Self-check requirements, justification levels

**Thinking Model:**
- **Layer A - Directive**: Senior-level roles, strategic goals, complex tasks
- **Layer B - Context**: Minimal essential context (no few-shot examples)
- **Layer C - Constraints**: Acceptance tests, high-level guardrails
- **Layer D - Process**: Advanced reasoning (Step-Back, Self-Consistency, etc.)
- **Layer E - Output**: Strategic formats with reasoning rationale
- **Layer F - Meta-Cognition**: Acceptance test validation, strategic checks

**Deep Research Model:**
- **Layer A - CASINO Framework**: Context, Audience, Scope, Intent, Narrator, Outcome
- **Layer B - Research Context**: Seed sources, evidence templates, citation examples
- **Layer C - Research Standards**: Evidence requirements, source validation
- **Layer D - Research Pipeline**: Plan→Search→Triage→Extract→Cross-verify→Synthesize→Cite
- **Layer E - Research Output**: Evidence tables, citations, confidence ratings
- **Layer F - Research Validation**: Source verification, evidence cross-checking

### 3. Interactive Interface
- **Tab-based Navigation**: Switch between Standard, Thinking, Deep Research models
- **Accordion Sections**: Collapsible framework layers for organized workflow
- **Live Prompt Preview**: Real-time generated prompt display in code format
- **Responsive Design**: Works on desktop and mobile devices

### 4. Export & Share
- **Copy to Clipboard**: One-click prompt copying functionality
- **JSON Export**: Download complete prompt configuration as JSON file
- **Template System**: Structured prompt shells for each model type

## Data Architecture

### Data Models
- **Prompt Configuration**: Model type, diagnostic answers, layer selections
- **Framework Data**: Options for roles, goals, tasks, constraints, formats
- **Template Shells**: Standard, Thinking, Deep Research prompt structures

### Storage Services
- **Client-side Storage**: Browser localStorage for session persistence
- **API Endpoints**: Hono-based REST API for prompt management
- **Export Files**: JSON configuration downloads

### Data Flow
1. **Diagnostic Phase**: User answers questions → Model recommendation
2. **Configuration Phase**: User selects options → Real-time prompt generation  
3. **Export Phase**: Generated prompt → Copy/download functionality

## Current Functional URIs

### Pages
- `/` - Main application with full prompt builder interface

### API Endpoints  
- `POST /api/prompts` - Save prompt configurations (accepts JSON payload)
- `GET /api/templates/standard` - Get Standard model prompt template
- `GET /api/templates/thinking` - Get Thinking model prompt template  
- `GET /api/templates/deep-research` - Get Deep Research model prompt template

### Static Assets
- `/static/app.js` - Main application JavaScript (32KB)
- **CDN Dependencies**: TailwindCSS, FontAwesome icons

## Features Not Yet Implemented ⏳

### 1. Advanced Features
- **Security Pack**: Prompt injection protection, guardrails configuration
- **Advanced Techniques**: Self-RAG, CRITIC, LATS integration  
- **Template Library**: Pre-built prompts for common use cases
- **Version Control**: Save/load prompt configurations
- **Collaboration**: Share prompts with teams

### 2. Analytics & Optimization
- **Performance Metrics**: Success rate tracking, acceptance tests
- **A/B Testing**: Compare prompt variations
- **Usage Analytics**: Most popular configurations

## User Guide

### Getting Started
1. **Choose Your Model**: Answer the diagnostic questions for personalized model recommendation
2. **Configure Layers**: Click through accordion sections to set up each framework layer
3. **Preview in Real-time**: Watch your prompt generate automatically in the preview pane
4. **Export Results**: Copy to clipboard or download JSON configuration

### Framework Methodology
Based on the latest AI research paper combining best practices for:
- **Standard Models**: Explicit instructions, detailed guidance, few-shot examples
- **Thinking Models**: High-level objectives, reasoning autonomy, verification contracts  
- **Deep Research Models**: Structured research pipelines, citation requirements, evidence validation

### Best Practices
- **Start with Diagnostics**: Always use the model selector for optimal results
- **Layer by Layer**: Complete each framework layer systematically
- **Test and Iterate**: Export and test prompts, then refine configurations
- **Save Configurations**: Download JSON files to preserve successful prompt setups

## Technical Details

### Technology Stack
- **Frontend**: Vanilla JavaScript, TailwindCSS, FontAwesome
- **Backend**: Hono framework on Cloudflare Workers
- **Development**: PM2 process management, Vite build system
- **Deployment**: Cloudflare Pages (edge computing)

### Project Structure
```
webapp/
├── src/index.tsx          # Main Hono application
├── public/static/app.js   # Frontend JavaScript (32KB)
├── ecosystem.config.cjs   # PM2 configuration
├── package.json           # Dependencies and scripts
├── vite.config.ts         # Build configuration  
└── wrangler.jsonc         # Cloudflare configuration
```

## Deployment Status
- **Platform**: Cloudflare Pages (ready for deployment)
- **Status**: ✅ Development Active
- **Environment**: Hono + TypeScript + TailwindCSS
- **Last Updated**: 2025-01-05

## Recommended Next Steps

### Immediate Priority
1. **Security Integration**: Add prompt injection protection and advanced guardrails
2. **Template Library**: Pre-built prompts for common business use cases  
3. **Advanced Techniques**: Integrate Self-RAG, CRITIC, and other research techniques

### Medium Priority  
4. **Export Enhancements**: Add more export formats (YAML, plain text, formatted)
5. **Model Testing Interface**: Direct integration with AI APIs for prompt testing

### Long-term Goals
6. **User Accounts**: Save and manage prompt libraries
7. **Collaboration Features**: Team sharing and prompt reviews  
8. **Analytics Dashboard**: Track prompt performance and success metrics
9. **Multi-language Support**: Internationalization for global usage

## Development Commands
```bash
npm run build              # Build for production
npm run dev:sandbox        # Start development server
npm run clean-port         # Clean up port 3000
npm run test              # Test service connectivity
pm2 start ecosystem.config.cjs  # Start with PM2
pm2 logs --nostream       # Check logs
```

The application successfully implements the complete 6-layer framework from the research paper across all three model types (Standard, Thinking, Deep Research), providing a comprehensive, intuitive interface for building optimized AI prompts based on the latest research and best practices.